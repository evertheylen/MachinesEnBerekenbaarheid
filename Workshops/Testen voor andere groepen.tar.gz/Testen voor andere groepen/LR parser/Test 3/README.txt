INPUT:
inputbestand: inputCFG3.xml
string: cdccd

OUPUT:
accepted