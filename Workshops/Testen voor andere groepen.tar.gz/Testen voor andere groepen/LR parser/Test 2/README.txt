INPUT:
inputbestand: inputCFG2.xml
string: xxzxx

OUPUT:
accepted