INPUT:
inputbestand: inputCFG1.xml
string: 1*00

OUTPUT:
rejected