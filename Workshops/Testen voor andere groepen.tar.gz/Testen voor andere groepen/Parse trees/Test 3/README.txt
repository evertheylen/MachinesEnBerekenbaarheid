Test de volgende CFG met de string:
010