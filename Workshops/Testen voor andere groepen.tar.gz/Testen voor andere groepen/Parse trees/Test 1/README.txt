Test de volgende CFG met de string:
a ∗ b